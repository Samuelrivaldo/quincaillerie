<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Model extends CI_Model {

    public function getUser() {
        $this->db->select('*');
        $this->db->from("contacts");
        $this->db->where('opened', 0);
        $query = $this->db->get();
        $message = $query->result();

        $this->db->select('*');
        $this->db->from("inscriptions");
        $this->db->join('services', 'inscriptions.services_IdService = services.IdService');
        $this->db->where('opened', 0);
        $query = $this->db->get();
        $inscription = $query->result();

        $notification['message'] = $message;
        $notification['inscription'] = $inscription;
        return $notification;
    }

    function truncate($text, $chars = 120) {
        if (strlen($text) > $chars) {
            $text = substr($text, 0, strrpos(substr($text, 0, $chars), ' ')) . '...';
        }
        return $text;
    }

    public function insert($data) {
        $this->db->insert($this->get_db_table(), $data);
    }

    public function insertEnMasse($data = array()) {
        $insert = $this->db->insert_batch($this->get_db_table(), $data);
        return $insert ? true : false;
    }

    public function insert_batch($data) {
        $this->db->insert_batch($this->get_db_table(), $data);
    }

    public function get_all() {
        $this->db->select('*');
        $this->db->from($this->get_db_table());
        $this->db->order_by($this->get_db_table_id(), 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function getCompanyInfos() {
        $this->db->select('*');
        $this->db->from('company');
        $query = $this->db->get();
        return $query->result();
    }

    public function get($id) {
        $query = $this->db->get_where($this->get_db_table(), array($this->get_db_table_id() => $id));
        return $query->row();
    }

    public function get_result($id) {
        $query = $this->db->get_where($this->get_db_table(), array($this->get_db_table_id() => $id));
        return $query->result();
    }

    public function update($id, $data) {
        $this->db->where($this->get_db_table_id(), $id);
        $this->db->update($this->get_db_table(), $data);
    }

    public function delete($id) {
        $this->db->where($this->get_db_table_id(), $id);
        $this->db->delete($this->get_db_table());
    }

    public function jointure($table1, $table2, $id) {
        $this->db->select('*');
        $this->db->from($table1);
        $this->db->join($table2, "$table1.$id = $table2.$id");
        $query = $this->db->get();
        return $query->result();
    }

    public function formatNumber($number) {
        return is_numeric($number) ? number_format($number, 0, ',', ' ') : $number;
    }

    function getByPeriode($begin, $end, $field, $orderBy = null) {
        $realDateBegin = date('Y-m-d', strtotime($begin));
        $realDateEnd = date('Y-m-d', strtotime($end));
        $this->db->select('*');
        $this->db->from($this->get_db_table());
        $this->db->where("$field >=", $realDateBegin);
        $this->db->where("$field <=", $realDateEnd);
        if (is_null($orderBy))
            $this->db->order_by($field, 'DESC');
        else
            $this->db->order_by($orderBy, 'DESC');
        $query = $this->db->get();
        return $query->result();
    }

    function getArray($id) {
        $vente = $this->vente_m->get($id);
        $clients = $this->client_m->get($vente->client_id);
        $commercial = $this->commercial_m->get($vente->commercial_id);

        $tva = ($vente->tva_id > 0) ? 18 : 0;

        $concerners = $this->detailvente_m->getByForeignKey($vente->idvente);
        $productArray = [];
        $totalRemise = 0;

        foreach ($concerners as $concerner) {
            $produit = $this->produit_m->get($concerner->produit_id);
            $productArray[] = [
                'Produit' => $produit->designation,
                'IdProduit' => $produit->idproduit,
                'Qte' => $concerner->qte,
                'Pu' => $concerner->pu,
                'Remise' => $concerner->remise,
                'Etat' => $concerner->etat,
                'IdDetail' => $concerner->iddetailvente
            ];
            $totalRemise += ($concerner->qte * $concerner->remise);
        }

        $paiements = $this->paiement_m->getByForeignKey($vente->idvente);
        $sommeVersee = $this->paiement_m->sum($paiements, 'montant');

        $totalRemise += $vente->remisefacture;
        $montTTC = $vente->montant + ($vente->montant * $tva / 100);
        $totalTTC = $montTTC - $totalRemise;
        $reste = $totalTTC - $sommeVersee;

        $globalState = "";
        if ($vente->etat == 0) {
            $globalState = $reste > 0 ? "Non Soldée" : "Soldée";
            $globalState .= $vente->etatlivraison == 1 ? " Livré" : " Non Livré";
        } else {
            $globalState = "Annulée";
        }

        return [
            'Vente' => $vente,
            'Client' => $clients,
            'Commercial' => $commercial,
            'Tva' => $tva,
            'MontTVA' => $vente->montant * $tva / 100,
            'MontHT' => $vente->montant,
            'TotalRemise' => $totalRemise,
            'Livraison' => $vente->etatlivraison == 1 ? 'Livré' : 'Non Livré',
            'MontTTC' => $montTTC,
            'TotalTTC' => $totalTTC,
            'Produits' => $productArray,
            'Paiements' => $paiements,
            'MontantVerse' => $sommeVersee,
            'Reste' => $reste,
            'GlobalState' => $globalState
        ];
    }

    function getArrayForService($id) {
        $service = $this->service_m->get($id);
        $clients = $this->client_m->get($service->client_id);
        $proforma = $this->proforma_m->getProformaByServiceId($service->idservice)[0] ?? null;

        if (!$proforma) {
            return [];
        }

        $tva = ($proforma->tva_id > 0) ? 18 : 0;

        $concerners = $this->detailproforma_m->getByForeignKey($proforma->idproforma);
        $productArray = [];
        $totalRemise = 0;

        foreach ($concerners as $concerner) {
            $produit = $this->produit_m->get($concerner->produit_id);
            $productArray[] = [
                'Produit' => $produit->designation,
                'IdProduit' => $produit->idproduit,
                'Qte' => $concerner->qte,
                'Pu' => $concerner->pu,
                'Remise' => $concerner->remise,
                'Etat' => $concerner->etat,
                'IdDetail' => $concerner->iddetailproforma
            ];
            $totalRemise += ($concerner->qte * $concerner->remise);
        }

        $totalRemise += $proforma->remisefacture;
        $montTTC = $proforma->montant + ($proforma->montant * $tva / 100);
        $totalTTC = $montTTC - $totalRemise;

        return [
            'Service' => $service,
            'Proforma' => $proforma,
            'Client' => $clients,
            'DetailProforma' => [
                'Tva' => $tva,
                'MontTVA' => $proforma->montant * $tva / 100,
                'MontHT' => $proforma->montant,
                'TotalRemise' => $totalRemise,
                'MontTTC' => $montTTC,
                'TotalTTC' => $totalTTC
            ],
            'Produits' => $productArray,
            'GlobalState' => $proforma->etat == 1 ? "Annulée" : "En Cours"
        ];
    }

    function getByForeignKey($idForeignKey) {
        $this->db->select('*');
        $this->db->from($this->get_db_table());
        $this->db->where($this->get_db_table_foreign(), $idForeignKey);
        $query = $this->db->get();
        return $query->result();
    }

    function sum($array, $field) {
        $sum = 0;
        foreach ($array as $item) {
            $sum += $item->$field;
        }
        return $sum;
    }
}
